import React, { useState, useEffect } from "react";
import axios from "axios";

export default function AddUser() {
  const [departments, setDepartments] = useState([]);
  const [designations, setDesignations] = useState([]);
  const [shifts, setShifts] = useState([]);
  const [empTypes, setEmpTypes] = useState([]);
  const [categories, setCategories] = useState([]);   // NEW
  const [salaryTypes, setSalaryTypes] = useState([]); // NEW
  const [autoGenerate, setAutoGenerate] = useState(false);

  const [formData, setFormData] = useState({
    collegeMail: "",
    doj: new Date().toISOString().split("T")[0], // defaults to today
    empNumber: "",
    weeklyOff: "",
    deptId: "",
    desgId: "",
    empType: "",
    categoryType: "",   // NEW
    shiftTypeId: "",
    // salaryTypeId: "",   // NEW
  });

  useEffect(() => {
    axios.get("http://localhost:5000/api/departments")
      .then(res => setDepartments(res.data))
      .catch(err => console.error(err));

    axios.get("http://localhost:5000/api/designations")
      .then(res => setDesignations(res.data))
      .catch(err => console.error(err));

    axios.get("http://localhost:5000/api/shifts")
      .then(res => setShifts(res.data))
      .catch(err => console.error(err));

    axios.get("http://localhost:5000/api/employeeTypes")
      .then(res => setEmpTypes(res.data))
      .catch(err => console.error(err));

    // NEW: Fetch categories
    axios.get("http://localhost:5000/api/categories")
      .then(res => setCategories(res.data))
      .catch(err => console.error(err));

    // NEW: Fetch salary types
  //   axios.get("http://localhost:5000/api/salaryTypes")
  //     .then(res => setSalaryTypes(res.data))
  //     .catch(err => console.error(err));
  }, []);

  const handleChange = (e) => {
    setFormData({...formData, [e.target.name]: e.target.value });
  };

  // Auto-generate Employee Number
  const handleAutoGenerate = async (checked) => {
    setAutoGenerate(checked);

    if (checked && formData.deptId) {
      try {
        const res = await axios.get(`http://localhost:5000/api/users/lastEmpNumber/${formData.deptId}`);
        const lastEmp = res.data?.empNumber || null;

        let newEmpNum = "";
        const dept = departments.find(d => d.deptId === parseInt(formData.deptId));

        if (lastEmp) {
          const num = parseInt(lastEmp.replace(/\D/g, "")) + 1;
          newEmpNum = `${dept.deptShort.toLowerCase()}${num}`;
        } else {
          newEmpNum = `${dept.deptShort.toLowerCase()}1`;
        }

        setFormData(prev => ({ ...prev, empNumber: newEmpNum }));
      } catch (err) {
        console.error("Error generating empNumber:", err);
      }
    } else {
      setFormData(prev => ({ ...prev, empNumber: "" }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post("http://localhost:5000/api/users", formData)
      .then(res => {
        alert("User added successfully!");
        setFormData({
          collegeMail: "",
          doj: new Date().toISOString().split("T")[0],
          empNumber: "",
          weeklyOff: "",
          deptId: "",
          desgId: "",
          empType: "",
          categoryType: "",
          shiftTypeId: "",
          salaryTypeId: "",
        });
        setAutoGenerate(false);
      })
      .catch(err => console.error(err));
  };

  return (
    <div className="max-w-lg mx-auto p-6 bg-white rounded-xl shadow-md mt-10">
      <h1 className="text-2xl font-bold mb-4">Add New User</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        
        <input type="email" name="collegeMail" placeholder="College Email"
          value={formData.collegeMail} onChange={handleChange}
          className="w-full p-2 border rounded" required />

        {/* Weekly Off Dropdown */}
        <select name="weeklyOff" value={formData.weeklyOff} onChange={handleChange}
          className="w-full p-2 border rounded" required>
          <option value="">Select Weekly Off</option>
          {["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]
            .map(day => <option key={day} value={day}>{day}</option>)}
        </select>

        {/* Department Dropdown */}
        <select name="deptId" value={formData.deptId} onChange={handleChange}
          className="w-full p-2 border rounded" required>
          <option value="">Select Department</option>
          {departments.map(dept => (
            <option key={dept.deptId} value={dept.deptId}>{dept.deptShort}</option>
          ))}
        </select>

        {/* Designation Dropdown */}
        <select name="desgId" value={formData.desgId} onChange={handleChange}
          className="w-full p-2 border rounded" required>
          <option value="">Select Designation</option>
          {designations.map(d => (
            <option key={d.desgId} value={d.desgId}>{d.desgShort}</option>
          ))}
        </select>

        {/* Employee Type Dropdown */}
        <select name="empType" value={formData.empType} onChange={handleChange}
          className="w-full p-2 border rounded" required>
          <option value="">Select Employee Type</option>
          {empTypes.map(e => (
            <option key={e.empTypeId} value={e.empTypeId}>{e.empTypeName}</option>
          ))}
        </select>

        {/* Shift Dropdown */}
        <select name="shiftTypeId" value={formData.shiftTypeId} onChange={handleChange}
          className="w-full p-2 border rounded" required>
          <option value="">Select Shift</option>
          {shifts.map(s => (
            <option key={s.shift_id} value={s.shift_id}>{s.shift_name}</option>
          ))}
        </select>

        {/* Category Dropdown (NEW) */}
        <select name="categoryType" value={formData.categoryType} onChange={handleChange}
          className="w-full p-2 border rounded" required>
          <option value="">Select Category</option>
          {categories.map(c => (
            <option key={c.category_id} value={c.category_id}>{c.categoryShort}</option>
          ))}
        </select>

        {/* Salary Type Dropdown (NEW)
        <select name="salaryTypeId" value={formData.salaryTypeId} onChange={handleChange}
          className="w-full p-2 border rounded" required>
          <option value="">Select Salary Type</option>
          {salaryTypes.map(s => (
            <option key={s.salaryTypeId} value={s.salaryTypeId}>{s.salaryTypeName}</option>
          ))}
        </select> */}

        {/* Employee Number with Auto Generate */}
        <div>
          <div className="flex items-center gap-2">
            <input
              type="text"
              name="empNumber"
              placeholder="Employee Number"
              value={formData.empNumber}
              onChange={handleChange}
              className="w-full p-2 border rounded"
              disabled={autoGenerate}
              required
            />
            <label className="flex items-center gap-1">
              <input
                type="checkbox"
                checked={autoGenerate}
                onChange={(e) => handleAutoGenerate(e.target.checked)}
              />
              Auto Generate
            </label>
          </div>
          {autoGenerate && !formData.deptId && (
            <p className="text-sm text-red-500 mt-1">
              Please select a department first
            </p>
          )}
        </div>

        <button type="submit"
          className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">
          Add User
        </button>
      </form>
    </div>
  );
}
