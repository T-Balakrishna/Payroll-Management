// const Category = require('../models/Category');

// // Create
// exports.createCategory = async (req, res) => {
//     try {
//         const { categoryName , categoryShort , maxLeaves , carryForward } = req.body;
//         console.log(categoryName);        
//         const newCategory = await Category.create({ categoryName , categoryShort , maxLeaves , carryForward});
//         res.status(201).json(newCategory);
//     } catch (error) {
//         console.log(req.body);
        
//         res.status(500).send("Error creating category: " + error.message);
//     }
// };

// // Get all active categorys
// exports.getAllCategories = async (req, res) => {
//     try {
//         const categories = await Category.findAll({ where: { status: 'active' } });
//         res.json(categories);
//     } catch (error) {
//         res.status(500).send("Error fetching categorys: " + error.message);
//     }
// };

// // Get active category by ID
// exports.getCategoryById = async (req, res) => {
//     try {
//         const category = await Category.findOne({ 
//             where: { category_id: req.params.id, status: 'active' } 
//         });
//         if (!category) return res.status(404).send("Category not found or inactive");
//         res.json(category);
//     } catch (error) {
//         res.status(500).send("Error fetching category: " + error.message);
//     }
// };

// // Update active category
// exports.updateCategory = async (req, res) => {
//     try {
//         const category = await Category.findOne({ 
//             where: { category_id: req.params.id, status: 'active' } 
//         });
//         if (!category) return res.status(404).send("Category not found or inactive");
//         await category.update(req.body);
//         res.json(category);
//     } catch (error) {
//         res.status(500).send("Error updating category: " + error.message);
//     }
// };

// // Soft delete (set status to inactive)
// exports.deleteCategory = async (req, res) => {
//     try {
//         const category = await Category.findOne({ 
//             where: { category_id: req.params.id, status: 'active' } 
//         });
//         if (!category) return res.status(404).send("Category not found or already inactive");
//         await category.update({ status: 'inactive' });
//         res.json({ message: "Category deactivated successfully" });
//     } catch (error) {
//         res.status(500).send("Error deleting category: " + error.message);
//     }
// };
