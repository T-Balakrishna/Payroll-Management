// const { DataTypes } = require('sequelize');
// const seq = require('../config/db');

// const Category = seq.define('Category', {
//     category_id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true, allowNull: false },
//     categoryName: { type: DataTypes.STRING, allowNull: false, unique: true },
//     categoryShort: { type: DataTypes.STRING, allowNull: false, unique: true },
//     maxLeaves: { type: DataTypes.INTEGER, allowNull: false, unique: false },
//     carryForward: { type: DataTypes.ENUM('yes', 'no'), defaultValue: 'no', allowNull: false },
//     status: { type: DataTypes.ENUM('active', 'inactive'), defaultValue: 'active', allowNull: false }
// });

// module.exports = Category;
